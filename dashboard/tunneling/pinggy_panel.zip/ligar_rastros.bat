@echo off
title Brotherhood Tunneling Control
echo Iniciando Motores Python 3.14...

"C:\Users\lorde\AppData\Local\Programs\Python\Python314\python.exe" "C:\xampp\htdocs\Sistema-login\tunneling\monitor_tunnel.py"
